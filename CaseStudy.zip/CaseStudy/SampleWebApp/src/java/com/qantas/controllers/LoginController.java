/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.controllers;

import com.qantas.beans.Login;
import com.qantas.services.LoginService;
import com.qantas.servicesfactory.ServiceFactory;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author USHA KIRAN
 */
public class LoginController extends HttpServlet {

    public void init( ){
        // no code
    }
   
   public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        String userName = request.getParameter("userName");
        String password = request.getParameter("password");
        String role = "";
        Login loginInfo = new Login( );
        loginInfo.setUserName(userName);
        loginInfo.setPassword(password);
        LoginService loginService = ServiceFactory.getLoginService();
        try{
         role = loginService.validateUser(loginInfo);
        }
        catch(ClassNotFoundException ce){
            ce.printStackTrace();
            // append exception message to log file
        }
        catch(SQLException se){
            se.printStackTrace( );
            // append exception message to log file
        }
        if( role.equalsIgnoreCase("admin")){
            HttpSession session = request.getSession();
            session.setAttribute("userName", userName);
            String adminPage = getServletContext( ).getInitParameter("adminHomePage");
            RequestDispatcher rd = request.getRequestDispatcher(adminPage);
            rd.forward(request, response);

        }

        if( role.equalsIgnoreCase("user")){
            HttpSession session = request.getSession();
            session.setAttribute("userName", userName);
            String userPage = getServletContext( ).getInitParameter("userHomePage");
            RequestDispatcher rd = request.getRequestDispatcher(userPage);
            rd.forward(request, response);

        }

        if( role.equalsIgnoreCase("invalid")){
            String invalidPage = getServletContext( ).getInitParameter("invalidPage");
            RequestDispatcher rd = request.getRequestDispatcher(invalidPage);
            rd.forward(request, response);

        }
    }

   public void destory( ){
       // no code
   }

   
}
