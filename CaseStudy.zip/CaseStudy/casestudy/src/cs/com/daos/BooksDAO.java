package cs.com.daos;

import java.sql.Connection;
import java.util.ArrayList;

import cs.com.models.Books;
import cs.com.models.Issue_Details;

public interface BooksDAO
{
	public Connection getConnection();
	public void closeConnection();
	
	public ArrayList<Books> getAllBooks();
	public ArrayList<Books> getAvailableBooks();
	public ArrayList<Books> allIssuedBooks();
	public ArrayList<Books> allReturnedBooks();
	
	public boolean updateBook(Books b);
	public boolean issueBook(int bookId,Issue_Details id);
	public boolean returnBook(int bookId,Issue_Details id);
	public boolean addBook(Books b);
	public Books getBook(int bookId);
	public Books getBook(String bookName, String author);
	public boolean removeBook(int bookId);
}
