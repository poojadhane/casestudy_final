/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.controllers;

import com.qantas.services.EmployeeService;
import com.qantas.servicesfactory.ServiceFactory;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USHA KIRAN
 */
public class ViewEmployeeDetailsController extends HttpServlet {
   
   
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
       
        EmployeeService employeeService = ServiceFactory.getEmployeeService();
        List allEmployeeDetails = null;
          try{
        allEmployeeDetails = employeeService.getAllEmployeeDetails();
          }
          catch(ClassNotFoundException ce){
              ce.printStackTrace();
              // append message into log file
          }
        catch(SQLException se ){
            se.printStackTrace();
            // append message into log file

        }

        request.setAttribute("employeeDetails", allEmployeeDetails);
        String viewAllEmployeeDetails = getServletContext( ).getInitParameter("viewAllEmployeeDetails");
         System.out.println( viewAllEmployeeDetails);
        RequestDispatcher rd = request.getRequestDispatcher(viewAllEmployeeDetails);
        rd.forward(request, response);
        
    } 

  
}
