package cs.com.daos;

import cs.com.models.Administrator;
//import oracle.ons.Connection;

public interface AdminDAO
{
	public java.sql.Connection getConnection();
	public void closeConnection();
	public boolean validateAdmin(Administrator a);
	public boolean updateAdmin(Administrator a);
	public Administrator getAdmin(String userName);
	public boolean passwordUpdate(String userName,String newpassword);
}
