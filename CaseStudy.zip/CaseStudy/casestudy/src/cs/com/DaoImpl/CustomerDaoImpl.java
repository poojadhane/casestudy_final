package cs.com.DaoImpl;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.PreparedStatement;

import cs.com.daos.CustomerDAO;
import cs.com.models.*;

public class CustomerDaoImpl implements CustomerDAO {

	private Connection con;
	private static final String conURL="jdbc:Oracle:thin:@localhost:1521:XE";
	private static final String dbUserName="system";
	private static final String dbPassword="system";
	private static String driverClass="oracle.jdbc.OracleDriver";
	
	public CustomerDaoImpl() {
			try {
				Class.forName(driverClass);
				System.out.println("------DRIVER LOADED-----");
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
		}
		
	public Connection getConnection() {
		
		try {
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("-----CONNECTED TO DB-----");
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	}

	public void closeConnection() {
		
		if(con!=null)
			try {
				con.close();
				System.out.println("---CONNECTION TO DB CLOSED----");
			} 
		catch (SQLException e) {
				e.printStackTrace();
			}

	}


	public boolean addCustomer(Customer c) {
		
		String SQL="insert into cust_tbl values(?,?,?,?,?,?,?,?,?,?,?)";
		//System.out.println("Shefuuuuuuuuuuuuuuuuuu");
		getConnection();
		boolean isAdded=false;
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1,c.getFirstName());
				ps.setString(2,c.getLastName());
				ps.setString(3,c.getUserName());
				ps.setString(4,c.getPassword());
				ps.setString(5,c.getEmailId());
				ps.setString(6,c.getPhoneNo());
				ps.setString(7,c.getMembershipType());
				ps.setDate(8,c.getDateOfJoining());
				ps.setString(9,c.getStatus());
				ps.setDouble(10,c.getOutstandingDues());
				ps.setString(11,c.getPaymentMode());
				System.out.println("mdgh "+c.getPaymentMode());
				int count=ps.executeUpdate();
				if(count==1)
				{
					isAdded=true;
					System.out.println("----CUSTOMER ADDED SUCCESSFULLY----");
				}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return isAdded;
	}


	public Customer getCustomer(String userName) {
		
		String SQL="select * from cust_tbl where username=?";
		Customer c=null;
		getConnection();
		
		try {
			c=new Customer();
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, userName);
			c.setUserName(userName);
			ResultSet rs= ps.executeQuery();
			if(rs.next()){
			c.setPassword(rs.getString("password"));
			c.setFirstName(rs.getString("firstname"));
			c.setLastName(rs.getString("lastname"));
			c.setEmailId(rs.getString("emailid"));
			c.setPhoneNo(rs.getString("phoneno"));
			c.setMembershipType(rs.getString("membershiptype"));
			c.setDateOfJoining(rs.getDate("dateofjoining"));
			c.setStatus(rs.getString("status"));
			c.setOutstandingDues(rs.getDouble("outstandingdues"));
			c.setPaymentMode(rs.getString("paymentmode"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return c;
	}


	public boolean updateCustomer(Customer c) {
		
		String SQL="update cust_tbl set firstname=?,"
				+ "lastname=?,emailid=?,"
				+ "phoneno=? where username=?";
		
		getConnection();
		boolean isUpdated=false;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, c.getFirstName());
			ps.setString(2, c.getLastName());
			ps.setString(3, c.getEmailId());
			ps.setString(4, c.getPhoneNo());
			ps.setString(5, c.getUserName());
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("---CUSTOMER UPDATED SUCCESSFULLY----");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		
		return isUpdated;

	}

	public ArrayList<Customer> getAllCustomers() {
		String SQL="select * from cust_tbl";
		ArrayList<Customer>custList=new ArrayList<Customer>();
		Customer c=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				c=new Customer();
				c.setFirstName(rs.getString("firstname"));
				c.setLastName(rs.getString("lastname"));
				c.setUserName(rs.getString("username"));
				c.setPassword(rs.getString("password"));
				c.setEmailId(rs.getString("emailid"));
				c.setPhoneNo(rs.getString("phoneno"));
				c.setMembershipType(rs.getString("membershiptype"));
				c.setDateOfJoining(rs.getDate("dateofjoining"));
				c.setStatus(rs.getString("status"));
				c.setOutstandingDues(rs.getDouble("outstandingdues"));
				c.setPaymentMode(rs.getString("paymentmode"));
				custList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return custList;
	}

	
	public boolean removeCustomer(String username) {
		
		String SQL="Delete from cust_tbl where username=?";
		
		boolean isDeleted=false;
		getConnection();
		
		try {
		
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, username);
			
			int cnt=ps.executeUpdate();
			
			if(cnt==1)
			{
				isDeleted=true;
				System.out.println("----USER DELETED SUCCESSFULLY");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return isDeleted;

	}


	public boolean validateCustomer(Customer c) {
		String SQL="select * from cust_tbl where username=? and password=?";
		boolean isValid=false;
		getConnection();
		
		try{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, c.getUserName());
			ps.setString(2, c.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				isValid=true;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return isValid;
	}


	public ArrayList<Customer> getNormalCustomers() {
		String SQL="select * from cust_tbl where membershiptype=?";
		ArrayList<Customer>custList=new ArrayList<Customer>();
		Customer c=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "Normal");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				c=new Customer();
				c.setFirstName(rs.getString("firstname"));
				c.setLastName(rs.getString("lastname"));
				c.setUserName(rs.getString("username"));
				c.setPassword(rs.getString("password"));
				c.setEmailId(rs.getString("emailid"));
				c.setPhoneNo(rs.getString("phoneno"));
				c.setMembershipType(rs.getString("membershiptype"));
				c.setDateOfJoining(rs.getDate("dateofjoining"));
				c.setStatus(rs.getString("status"));
				c.setOutstandingDues(rs.getDouble("outstandingdues"));
				c.setPaymentMode(rs.getString("paymentmode"));
				custList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return custList;
	}


	public ArrayList<Customer> getPremiumCustomers() {
		String SQL="select * from cust_tbl where membershiptype=?";
		ArrayList<Customer>custList=new ArrayList<Customer>();
		Customer c=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "Premium");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				c=new Customer();
				c.setFirstName(rs.getString("firstname"));
				c.setLastName(rs.getString("lastname"));
				c.setUserName(rs.getString("username"));
				c.setPassword(rs.getString("password"));
				c.setEmailId(rs.getString("emailid"));
				c.setPhoneNo(rs.getString("phoneno"));
				c.setMembershipType(rs.getString("membershiptype"));
				c.setDateOfJoining(rs.getDate("dateofjoining"));
				c.setStatus(rs.getString("status"));
				c.setOutstandingDues(rs.getDouble("outstandingdues"));
				c.setPaymentMode(rs.getString("paymentmode"));
				custList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return custList;
	}


	public ArrayList<Customer> getActiveCustomers() {
		String SQL="select * from cust_tbl where status=?";
		ArrayList<Customer>custList=new ArrayList<Customer>();
		Customer c=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "active");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				c=new Customer();
				c.setFirstName(rs.getString("firstname"));
				c.setLastName(rs.getString("lastname"));
				c.setUserName(rs.getString("username"));
				c.setPassword(rs.getString("password"));
				c.setEmailId(rs.getString("emailid"));
				c.setPhoneNo(rs.getString("phoneno"));
				c.setMembershipType(rs.getString("membershiptype"));
				c.setDateOfJoining(rs.getDate("dateofjoining"));
				c.setStatus(rs.getString("status"));
				c.setOutstandingDues(rs.getDouble("outstandingdues"));
				c.setPaymentMode(rs.getString("paymentmode"));
				custList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return custList;
	}


	public ArrayList<Customer> getInactiveCustomers() {
		String SQL="select * from cust_tbl where status=?";
		ArrayList<Customer>custList=new ArrayList<Customer>();
		Customer c=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "inactive");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				c=new Customer();
				c.setFirstName(rs.getString("firstname"));
				c.setLastName(rs.getString("lastname"));
				c.setUserName(rs.getString("username"));
				c.setPassword(rs.getString("password"));
				c.setEmailId(rs.getString("emailid"));
				c.setPhoneNo(rs.getString("phoneno"));
				c.setMembershipType(rs.getString("membershiptype"));
				c.setDateOfJoining(rs.getDate("dateofjoining"));
				c.setStatus(rs.getString("status"));
				c.setOutstandingDues(rs.getDouble("outstandingdues"));
				c.setPaymentMode(rs.getString("paymentmode"));
				custList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return custList;
	}


	public boolean updateCustomerDues() {
		String SQL="update cust_tbl set outstandingdues=? where username=?";
		String sql="select * from issue_Details where fineamount>0";
		getConnection();
		boolean isUpdated=false;
		
		try {
			PreparedStatement ps1=con.prepareStatement(sql);
			ps1.clearParameters();
			ResultSet rs=ps1.executeQuery();
				while(rs.next()){
					PreparedStatement ps=con.prepareStatement(SQL);
					ps.clearParameters();
					ps.setLong(1, rs.getLong("fineamount"));
					ps.setString(2, rs.getString("userName"));
					int cnt=ps.executeUpdate();
					if(cnt==1){
						isUpdated=true;
						System.out.println("--OUTSTANDING DUES HAVE BEEN UPDATED");
					}
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return isUpdated;
	}


	public boolean customerInactive(String userName) {

		String sql="select status from cust_tbl where username=?";
		boolean isInactive=false;
		getConnection();
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.clearParameters();
			ps.setString(1, userName);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				if(rs.getString("status").equals("inactive"))
					isInactive=true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return isInactive;
	}


	public boolean passwordUpdate(String userName, String newpassword) {
		String SQL="update cust_tbl set password=? " +
				"where userName=?";
		getConnection();
		boolean isUpdated=false;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, newpassword);
			ps.setString(2, userName);
			
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isUpdated=true;
				System.out.println("---PASSWORD UPDATED");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isUpdated;
	}

}
