package cs.com.filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.models.Administrator;
import cs.com.models.Customer;

public class UpdatePhoneFilter implements Filter {

    public UpdatePhoneFilter() {
        
    }

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse res=(HttpServletResponse)response;
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		
		HttpSession session=req.getSession();
		Customer cust=(Customer)session.getAttribute("Cust");
		Administrator admin=(Administrator)session.getAttribute("Admin");
		
		String phoneNo=request.getParameter("phoneNo");
	
		if(phoneNo.length()!=10){
			if(admin==null){
				
				RequestDispatcher rd=request.getRequestDispatcher("/updateprofile.jsp");
				out.println("<h4>Please enter a valid Number ID<h4>");
				rd.include(request, response);
				}
				else if(cust==null)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/updateprofileadmin.jsp");
					out.println("<h4>Please enter a valid Number ID<h4>");
					rd.include(request, response);
				}
		}
		else 
		chain.doFilter(request, response);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
