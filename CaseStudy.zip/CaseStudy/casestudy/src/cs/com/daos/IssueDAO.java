package cs.com.daos;

import java.sql.Connection;
import java.util.ArrayList;
import java.sql.Date;

import cs.com.models.Issue_Details;

public interface IssueDAO 
{
	public Connection getConnection();
	public void closeConnection();
	public boolean addIssueDetails(Issue_Details id);
	public ArrayList<Issue_Details> allIssueDetails();
	public ArrayList<Issue_Details> PendingRequestDetails();
	public ArrayList<Issue_Details> getIssueDetails(String userName);
	public int countBooksIssued(String userName);
	public boolean updateRejectDetails(int bookId,Issue_Details id);
	public boolean updateFineAmount(int bookId,Date issuedate);
	public long calcFineAmount(Date issuedate);
	public Issue_Details getIssueDetails(int bookId,String requeststatus);
	public ArrayList<Issue_Details> generateReport();
	public ArrayList<Issue_Details> getFineDetails(String userName);
	public boolean updateFineAmount1(int bookId,Date issuedate,Date returndate);
	public long calcFineAmount1(Date issuedate,Date returndate);
	public boolean updateIssueDetails(Issue_Details id);
	public boolean updateFineDetails(String userName,int bookId,String bookName);
	public Issue_Details getIssueDetails(String userName,int bookId,String bookName);
	public ArrayList<Issue_Details> StatusUpdate();
	public boolean changeStatus(String userName);
}
