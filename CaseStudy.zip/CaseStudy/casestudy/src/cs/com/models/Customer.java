package cs.com.models;

import java.sql.Date;

public class Customer {
	
	private String firstName;
	private String lastName;
	private String userName;
	private String password;
	private String emailId;
	private String phoneNo;
	private String membershipType;
	private Date dateOfJoining;
	private String status;
	private double outstandingDues;
	private String paymentMode;
	
	public Customer(){
		
	}
	public Customer(String firstName, String lastName, String userName,
			String password, String emailId, String phoneNo,
			String membershipType, Date dateOfJoining, String status,
			double outstandingDues, String paymentMode) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.password = password;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.membershipType = membershipType;
		this.dateOfJoining = dateOfJoining;
		this.status = status;
		this.outstandingDues = outstandingDues;
		this.paymentMode = paymentMode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getMembershipType() {
		return membershipType;
	}

	public void setMembershipType(String membershipType) {
		this.membershipType = membershipType;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getOutstandingDues() {
		return outstandingDues;
	}

	public void setOutstandingDues(double outstandingDues) {
		this.outstandingDues = outstandingDues;
	}
	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	
}
 