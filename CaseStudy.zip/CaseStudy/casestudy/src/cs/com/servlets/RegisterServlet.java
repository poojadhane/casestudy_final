package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.DaoImpl.CustomerDaoImpl;
import cs.com.daos.CustomerDAO;
import cs.com.models.Customer;

public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Customer cust;
	CustomerDAO cd=new CustomerDaoImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		cust = new Customer();
		String s=(String) session.getAttribute("mem");
		String m=(String) session.getAttribute("mode");

		cust.setFirstName(request.getParameter("firstName"));
		cust.setLastName(request.getParameter("lastName"));
		cust.setUserName(request.getParameter("userName"));
		cust.setPassword(request.getParameter("password"));
		cust.setEmailId(request.getParameter("emailId"));
		cust.setPhoneNo(request.getParameter("phoneNo"));
		cust.setDateOfJoining(new Date(System.currentTimeMillis()));
		cust.setOutstandingDues(0.0);
		cust.setMembershipType(s);
		cust.setStatus("active");
		cust.setPaymentMode(m);
		
		session.setAttribute("customer", cust);
		PrintWriter pw=response.getWriter();
		//pw.print("Poojaaaaaaaaaaaaaaaaaaa");
		
		System.out.println("valid membership is "+cust.getMembershipType());
		System.out.println("Mode is "+cust.getPaymentMode());
		cd.addCustomer(cust);
		
		RequestDispatcher rd=request.getRequestDispatcher("/payment.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
