
package cs.com.DaoImpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

import cs.com.daos.CustomerDAO;
import cs.com.daos.IssueDAO;
import cs.com.models.Issue_Details;

public class IssueDaoImpl implements IssueDAO {
	
	private Connection con;
	private static final String conURL="jdbc:Oracle:thin:@localhost:1521:XE";
	private static final String dbUserName="system";
	private static final String dbPassword="system";
	private static String driverClass="oracle.jdbc.OracleDriver";
	CustomerDAO cd=new CustomerDaoImpl();
	
	public IssueDaoImpl() {
			try {
				Class.forName(driverClass);
				System.out.println("------DRIVER LOADED-----");
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
		}
		
	public Connection getConnection() {
		
		try {
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("-----CONNECTED TO DB-----");
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	}


	public void closeConnection() {
		
		if(con!=null)
			try {
				con.close();
				System.out.println("---CONNECTION TO DB CLOSED----");
			} 
		catch (SQLException e) {
				e.printStackTrace();
			}

	}
	Calendar cal=Calendar.getInstance();

	public boolean addIssueDetails(Issue_Details id) {
		String SQL="insert into issue_details values(?,?,?,?,?,?,?,?,?)";
		getConnection();
		boolean isAdded=false;
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
				ps.setString(1, id.getUserName());
			    ps.setInt(2, id.getBookId());
			    ps.setString(3, id.getBookName());
			    ps.setDate(4, new Date(System.currentTimeMillis()));
			    ps.setDate(5, new Date(System.currentTimeMillis()));
				ps.setString(6, id.getRequest());
				ps.setString(7, id.getRequestStatus());
				ps.setInt(8, 20);
				ps.setString(9, "Not Paid");
				int count=ps.executeUpdate();
				if(count==1)
				{
					isAdded=true;
					System.out.println("----BOOK REQUEST ADDED SUCCESSFULLY----");
				}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return isAdded;
		
	}


	public ArrayList<Issue_Details> allIssueDetails() {
		
		String SQL="select * from issue_details";
		
		getConnection();
		
		ArrayList<Issue_Details> idList=new ArrayList<Issue_Details>();
		Issue_Details id=null;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			ps.clearParameters();
			while(rs.next()){
				id=new Issue_Details();
				id.setUserName(rs.getString("username"));
			    id.setBookId(rs.getInt("bookid"));
			    id.setBookName((rs.getString("bookname")));
				id.setIssueDate(rs.getDate("issuedate"));
				id.setReturnDate(rs.getDate("returndate"));
				id.setRequest(rs.getString("request"));
				id.setRequestStatus(rs.getString("requeststatus"));
				id.setFineAmount(rs.getInt("fineamount"));
				id.setRemarks(rs.getString("remarks"));
				id.setFinestatus(rs.getString("finestatus"));
				idList.add(id);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return idList;
	}
	
	public ArrayList<Issue_Details> allFineDetails() {
		
		String SQL="select * from issue_details where fineamount>0 and finestatus='Not Paid'";
		
		getConnection();
		
		ArrayList<Issue_Details> idList=new ArrayList<Issue_Details>();
		Issue_Details id=null;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			ps.clearParameters();
			while(rs.next()){
				id=new Issue_Details();
				id.setUserName(rs.getString("username"));
			    id.setBookId(rs.getInt("bookid"));
			    id.setBookName((rs.getString("bookname")));
				id.setIssueDate(rs.getDate("issuedate"));
				id.setReturnDate(rs.getDate("returndate"));
				id.setRequest(rs.getString("request"));
				id.setRequestStatus(rs.getString("requeststatus"));
				id.setFineAmount(rs.getInt("fineamount"));
				id.setRemarks(rs.getString("remarks"));
				id.setFinestatus(rs.getString("finestatus"));
				idList.add(id);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return idList;
	}

	public Issue_Details getIssueDetails(int bookId,String requeststatus) {
		
		String SQL="select * from issue_details where bookid=? and requeststatus=?";
		
		getConnection();

		Issue_Details id=null;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);

			ps.clearParameters();
			ps.setInt(1, bookId);
			ps.setString(2, requeststatus);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				id=new Issue_Details();
				id.setUserName(rs.getString("username"));
			    id.setBookId(rs.getInt("bookid"));
			    id.setBookName(rs.getString("bookname"));
				id.setIssueDate(rs.getDate("issuedate"));
				id.setReturnDate(rs.getDate("returndate"));
				id.setRequest(rs.getString("request"));
				id.setRequestStatus(rs.getString("requeststatus"));
				id.setFineAmount(rs.getInt("fineamount"));
				id.setRemarks(rs.getString("remarks"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return id;
	}
	
public ArrayList<Issue_Details> PendingRequestDetails() {
		
		String SQL="select * from issue_details where requeststatus=?";
		
		getConnection();
		
		ArrayList<Issue_Details> idList=new ArrayList<Issue_Details>();
		Issue_Details id=null;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "Pending");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				id=new Issue_Details();
				id.setUserName(rs.getString("username"));
			    id.setBookId(rs.getInt("bookid"));
			    id.setBookName(rs.getString("bookname"));
				id.setIssueDate(rs.getDate("issuedate"));
				id.setReturnDate(rs.getDate("returndate"));
				id.setRequest(rs.getString("request"));
				id.setRequestStatus(rs.getString("requeststatus"));
				id.setFineAmount(rs.getInt("fineamount"));
				id.setRemarks(rs.getString("remarks"));
				idList.add(id);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return idList;
	}

	public ArrayList<Issue_Details> getIssueDetails(String userName) {
	
	String SQL="select * from issue_details where username=?";
	
	getConnection();
	Issue_Details id=null;
	ArrayList<Issue_Details> idList=new ArrayList<Issue_Details>();
	try {
		PreparedStatement ps=con.prepareStatement(SQL);
		ps.setString(1, userName);
		ResultSet rs=ps.executeQuery();
		ps.clearParameters();
		while(rs.next()){
			id=new Issue_Details();
			id.setUserName(rs.getString("username"));
		    id.setBookId(rs.getInt("bookid"));
		    id.setBookName(rs.getString("bookname"));
			id.setIssueDate(rs.getDate("issuedate"));
			id.setReturnDate(rs.getDate("returndate"));
			id.setRequest(rs.getString("request"));
			id.setRequestStatus(rs.getString("requeststatus"));
			id.setFineAmount(rs.getInt("fineamount"));
			id.setRemarks(rs.getString("remarks"));
			idList.add(id);
		}
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	finally{
		closeConnection();
	}
		
	return idList;
}

	public ArrayList<Issue_Details> getFineDetails(String userName) {
		
	String SQL="select * from issue_details where username=? and fineamount>0";
	
	getConnection();
	Issue_Details id=null;
	ArrayList<Issue_Details> idList=new ArrayList<Issue_Details>();
	
	try {
		PreparedStatement ps=con.prepareStatement(SQL);
		ps.setString(1, userName);
		ResultSet rs=ps.executeQuery();
		ps.clearParameters();
		while(rs.next()){
			id=new Issue_Details();
			id.setUserName(rs.getString("username"));
		    id.setBookId(rs.getInt("bookid"));
		    id.setBookName(rs.getString("bookname"));
			id.setIssueDate(rs.getDate("issuedate"));
			id.setReturnDate(rs.getDate("returndate"));
			id.setRequest(rs.getString("request"));
			id.setRequestStatus(rs.getString("requeststatus"));
			id.setFineAmount(rs.getInt("fineamount"));
			id.setRemarks(rs.getString("remarks"));
			idList.add(id);
		}
	} catch (SQLException e) 
	{
		
		e.printStackTrace();
	}
	finally{
		closeConnection();
	}
		
	return idList;
}
	

	public int countBooksIssued(String userName) {
		String SQL="select * from issue_details where request=? and requeststatus=? and username=?";
	
		getConnection();
		
		ArrayList<Issue_Details> idList=new ArrayList<Issue_Details>();
		Issue_Details id=null;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "Issue");
			ps.setString(2, "Approved");
			ps.setString(3, userName);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				id=new Issue_Details();
				id.setUserName(rs.getString("username"));
			    id.setBookId(rs.getInt("bookid"));
			    id.setBookName(rs.getString("bookname"));
				id.setIssueDate(rs.getDate("issuedate"));
				id.setReturnDate(rs.getDate("returndate"));
				id.setRequest(rs.getString("request"));
				id.setRequestStatus(rs.getString("requeststatus"));
				id.setFineAmount(rs.getInt("fineamount"));
				id.setRemarks(rs.getString("remarks"));
				System.out.println("+++++++++++++++++++");
				idList.add(id);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		System.out.println("idList.size()idList.size()idList.size()"+idList.size());
		return idList.size();
		
	}
	
	public boolean updateRejectDetails(int bookId,Issue_Details id){
		
		String SQL="update issue_details set requeststatus=? where bookid=? and username=?" +
				"and request=?";
		getConnection();
		boolean isUpdated=false;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "Rejected");
			ps.setInt(2, bookId);
			ps.setString(3, id.getUserName());
			ps.setString(4, id.getRequest());
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isUpdated=true;
				System.out.println("---REJECTED");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return isUpdated;
	}

	
	public boolean updateFineAmount(int bookId,Date issuedate) {
		
		String SQL="update issue_details set fineamount=?" +
				"where bookid=?";
		getConnection();
		boolean isUpdated=false;
		Long dues=calcFineAmount(issuedate);
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.setLong(1, dues);
			ps.setInt(2, bookId);
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isUpdated=true;
				System.out.println("--FINE AMOUNT UPDATED--");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return isUpdated;
	}

	public long calcFineAmount(Date issuedate){
		
		long fineAmount=0;
		
		Date currentdate=new Date(System.currentTimeMillis());
		long diff=currentdate.getTime()-issuedate.getTime();
		long diffdays=(diff)/(60*60*24*1000);
		
		if(diffdays<5){
			fineAmount=0;
		}
		else
			fineAmount=diffdays-5;
		
		return fineAmount;
	}
	
	public ArrayList<Issue_Details> generateReport(){
		
		ArrayList<Issue_Details> id=allIssueDetails();
		ArrayList<Issue_Details> report=new ArrayList<Issue_Details>();
		boolean isUpdated=false;
		getConnection();
		
		for(Issue_Details i:id){
			if(i.getRequest().equals("Issue") && i.getRequestStatus().equals("Approved") && 
					i.getFinestatus().equals("Not Paid")){
				
				isUpdated=updateFineAmount(i.getBookId(),i.getIssueDate());
				if(isUpdated){
					System.out.println("FINE AMOUNT UPDATED!");
				}
			}
			else if(i.getRequest().equals("Return") && i.getRequestStatus().equals("Approved") 
					&& i.getFinestatus().equals("Not Paid")){
				updateFineAmount1(i.getBookId(), i.getIssueDate(), i.getReturnDate());
			}
		}
		if(isUpdated)
		{
	     report=allFineDetails();
	     System.out.println("--REPORT GENERATED---");
		}
		
		return report;
	}

	public boolean updateFineAmount1(int bookId,Date issuedate,Date returndate) {
		
		String SQL="update issue_details set fineamount=?" +
				"where bookid=?";
		getConnection();
		boolean isUpdated=false;
		long dues=calcFineAmount1(issuedate,returndate);
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.setLong(1, dues);
			ps.setInt(2, bookId);
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isUpdated=true;
				System.out.println("--FINE AMOUNT UPDATED--");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return isUpdated;
	}

	public long calcFineAmount1(Date issuedate,Date returndate){
		
		long fineAmount=0;
		
		long diff=returndate.getTime()-issuedate.getTime();
		long diffdays=(diff)/(60*60*24*1000);
		
		if(diffdays<5){
			fineAmount=0;
		}
		else
			fineAmount=diffdays-5;
		
		return fineAmount;
	}
	

	public boolean updateIssueDetails(Issue_Details id) {
		
		String SQL="update issue_details set request=?,requeststatus=? " +
				"where bookid=? and bookname=?";
		getConnection();
		boolean isUpdated=false;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, id.getRequest());
			ps.setString(2, id.getRequestStatus());
			ps.setInt(3, id.getBookId());
			ps.setString(4, id.getBookName());
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				System.out.println("---BOOK RETURN DETAILS UPDATED---");
				isUpdated=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return isUpdated;
	}

	public boolean updateFineDetails(String userName, int bookId,
			String bookName) {
		String SQL="update cust_tbl set outstandingdues=0,status='active' where username=?";
		String sql="update issue_details set fineamount=0,finestatus='Paid'" +
				" where username=? and bookid=? and bookname=?";
		getConnection();
		boolean isupdated=false;
		
			try {
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, userName);
				int cnt=ps.executeUpdate();
				
				PreparedStatement ps1=con.prepareStatement(sql);
				ps1.clearParameters();
				ps1.setString(1, userName);
				ps1.setInt(2, bookId);
				ps1.setString(3, bookName);
				int cnt1=ps1.executeUpdate();
				
				if(cnt==1 && cnt1==1){
					isupdated=true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		return isupdated;
	}


	public Issue_Details getIssueDetails(String userName, int bookId,
			String bookName) {
String SQL="select * from issue_details where username=? and " +
		"bookid=? and bookname=?";
		
		getConnection();

		Issue_Details id=null;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);

			ps.clearParameters();
			ps.setString(1, userName);
			ps.setInt(2, bookId);
			ps.setString(3, bookName);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				id=new Issue_Details();
				id.setUserName(rs.getString("username"));
			    id.setBookId(rs.getInt("bookid"));
			    id.setBookName(rs.getString("bookname"));
				id.setIssueDate(rs.getDate("issuedate"));
				id.setReturnDate(rs.getDate("returndate"));
				id.setRequest(rs.getString("request"));
				id.setRequestStatus(rs.getString("requeststatus"));
				id.setFineAmount(rs.getInt("fineamount"));
				id.setRemarks(rs.getString("remarks"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return id;
	}


	public ArrayList<Issue_Details> StatusUpdate() {
String SQL="select * from issue_details i,cust_tbl c where i.fineamount>29 and" +
		" i.finestatus='Not Paid' and c.username=i.username";
		
		getConnection();
		
		ArrayList<Issue_Details> idList=new ArrayList<Issue_Details>();
		Issue_Details id=null;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			ps.clearParameters();
			while(rs.next()){
				id=new Issue_Details();
				id.setUserName(rs.getString("username"));
			    id.setBookId(rs.getInt("bookid"));
			    id.setBookName((rs.getString("bookname")));
				id.setIssueDate(rs.getDate("issuedate"));
				id.setReturnDate(rs.getDate("returndate"));
				id.setRequest(rs.getString("request"));
				id.setRequestStatus(rs.getString("requeststatus"));
				id.setFineAmount(rs.getInt("fineamount"));
				id.setRemarks(rs.getString("remarks"));
				id.setFinestatus(rs.getString("finestatus"));
				idList.add(id);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return idList;
	}


	public boolean changeStatus(String userName) {
		
		String SQL="update cust_tbl set status='inactive' where username=?";
		boolean isChanged=false;
		getConnection();
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, userName);
			
			int cnt=ps.executeUpdate();
			
			if(cnt==1){
				isChanged=true;
				System.out.println("---STATUS CHANGED TO INACTIVE---");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return isChanged;
		}

	

	
	

}
