
package com.qantas.daoimplementations;

import com.qantas.beans.Employee;
import com.qantas.daointerfaces.EmployeeDao;
import com.qantas.utilities.DatabaseConnectionUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USHA KIRAN
 */
public class EmployeeDaoImplementation  implements EmployeeDao{

    public List getAllEmployeeDetails( )throws ClassNotFoundException, SQLException{
        List employeeList = new ArrayList( );
        Connection con = DatabaseConnectionUtility.getConnection();
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select * from emp");
        Employee emp = null;
        while(rs.next()){
            emp = new Employee( );
            emp.setEmployeeIdentification(rs.getString("empid"));
            emp.setEmployeeName(rs.getString("empname"));
            emp.setBasicSalary(rs.getInt("basic"));

            employeeList.add(emp);

        }
        DatabaseConnectionUtility.closeConnection(con);

        return employeeList;
    }

    public void addNewEmployee(Employee employee ) throws ClassNotFoundException, SQLException{

        Connection con = DatabaseConnectionUtility.getConnection();
        PreparedStatement psmt = con.prepareStatement("insert into emp values(?,?,?)");
         psmt.setString(1, employee.getEmployeeIdentification());
         psmt.setString(2, employee.getEmployeeName());
         psmt.setInt(3, employee.getBasicSalary());
         psmt.executeUpdate();
         DatabaseConnectionUtility.closeConnection(con);
    }

}
