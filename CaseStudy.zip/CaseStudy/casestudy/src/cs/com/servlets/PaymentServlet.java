package cs.com.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.DaoImpl.CustomerDaoImpl;
import cs.com.daos.CustomerDAO;
import cs.com.models.Customer;

public class PaymentServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	CustomerDAO cd=new CustomerDaoImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		Customer cust=(Customer) session.getAttribute("customer");
		
		String membershipType=request.getParameter("membershipType");
		System.out.println("mem is"+membershipType);
		String paymentMode=request.getParameter("paymentMode");
		System.out.println("mode is "+paymentMode);
		session.setAttribute("mem", membershipType);
		
		session.setAttribute("mode", paymentMode);
	
		
		cust.setMembershipType(membershipType);
		cust.setPaymentMode(paymentMode);
		cust.setStatus("active");
		cd.updateCustomer(cust);
		
		RequestDispatcher rd=request.getRequestDispatcher("/paymentdetails.jsp");
		rd.forward(request, response);
	}
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
