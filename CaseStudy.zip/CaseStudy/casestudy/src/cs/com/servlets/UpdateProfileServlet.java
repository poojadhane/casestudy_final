package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.DaoImpl.AdminDaoImpl;
import cs.com.DaoImpl.CustomerDaoImpl;
import cs.com.daos.AdminDAO;
import cs.com.daos.CustomerDAO;
import cs.com.models.Administrator;
import cs.com.models.Customer;

public class UpdateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CustomerDAO cd=new CustomerDaoImpl();
	AdminDAO ad=new AdminDaoImpl();
	
	public void init(ServletConfig config) throws ServletException {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		Customer cust=(Customer)session.getAttribute("Cust");
		Administrator admin=(Administrator)session.getAttribute("Admin");
		
		String emailId=request.getParameter("emailId");
		String phoneNo=request.getParameter("phoneNo");
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		if(admin==null){
			
			RequestDispatcher rd=request.getRequestDispatcher("/homepage1.jsp");
			
			cust.setEmailId(emailId);
			cust.setPhoneNo(phoneNo);
			
			boolean a=cd.updateCustomer(cust);
			
			if(a){
				out.println("<h3><b><i>Details were updated</i></b></h3>");
				rd.include(request, response);
			}
			else{
				out.println("<h3><b><i>Error in Updation, please try later</i></b></h3>");
				rd.include(request, response);
		}
		}
		else if(cust==null)
		{
			RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
			
			admin.setEmailId(emailId);
			admin.setPhoneNo(phoneNo);
			
			boolean a=ad.updateAdmin(admin);
			
			if(a){
				out.println("<h3><b><i>Details were updated</i></b></h3>");
				rd.include(request, response);
			}
			else{
				out.println("<h3><b><i>Error in Updation, please try later</i></b></h3>");
				rd.include(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
