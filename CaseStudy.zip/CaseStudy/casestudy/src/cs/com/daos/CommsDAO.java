package cs.com.daos;

import java.sql.Connection;
import java.util.ArrayList;

import cs.com.models.Comms;

public interface CommsDAO
{
	public Connection getConnection();
	public void closeConnection();
	public boolean addComments(Comms b);
	public ArrayList<Comms> getComments();
	public boolean removeComment(int bookId);
}
