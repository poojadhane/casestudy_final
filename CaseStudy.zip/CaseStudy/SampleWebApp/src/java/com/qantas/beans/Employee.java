/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.beans;

import java.io.Serializable;

/**
 *
 * @author USHA KIRAN
 */
public class Employee implements Serializable {
    private String employeeIdentification;
    private String employeeName;
    private int basicSalary;

    public Employee( ){
        // no code
    }
    

    public int getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(int basicSalary) {
        this.basicSalary = basicSalary;
    }

    public String getEmployeeIdentification() {
        return employeeIdentification;
    }

    public void setEmployeeIdentification(String employeeIdentification) {
        this.employeeIdentification = employeeIdentification;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }



}
