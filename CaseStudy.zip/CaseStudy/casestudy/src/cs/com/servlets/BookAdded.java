package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.com.DaoImpl.BooksDaoImpl;
import cs.com.DaoImpl.CommsDaoImpl;
import cs.com.daos.BooksDAO;
import cs.com.daos.CommsDAO;
import cs.com.models.Books;
import cs.com.models.Comms;

public class BookAdded extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CommsDAO com=new CommsDaoImpl();
	Comms c=new Comms();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String bookName=request.getParameter("bookName");
		String author=request.getParameter("author");
		String comments=request.getParameter("comments");
		
		Books b=new Books();
		BooksDAO cd=new BooksDaoImpl();
		b.setBookName(bookName);
		b.setAuthor(author);
		
		boolean isAdded=cd.addBook(b);
		if(isAdded){
			b=cd.getBook(bookName, author);
			c.setBookId(b.getBookId());
			c.setBookName(bookName);
			c.setComments(comments);
			com.addComments(c);
			
			out.println("<h3>Book has been added successfully</h3>");
			RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
			rd.include(request, response);
		}
		else{
			out.println("<h3>Error in adding the book <br>Please try again later</h3>");
			RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
