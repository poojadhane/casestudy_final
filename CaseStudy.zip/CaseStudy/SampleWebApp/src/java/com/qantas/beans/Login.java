/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.beans;

import java.io.Serializable;

/**
 *
 * @author USHA KIRAN
 */
public class Login  implements Serializable{
    private String userName;
    private String password;

     public Login( ){
        // no code
    }
    

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }




}
