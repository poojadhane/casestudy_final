package cs.com.DaoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import cs.com.daos.CommsDAO;
import cs.com.models.Comms;

public class CommsDaoImpl implements CommsDAO {

	private Connection con;
	private static final String conURL="jdbc:Oracle:thin:@localhost:1521:XE";
	private static final String dbUserName="system";
	private static final String dbPassword="system";
	private static String driverClass="oracle.jdbc.OracleDriver";
	
	public CommsDaoImpl() {
		try {
			Class.forName(driverClass);
			System.out.println("------DRIVER LOADED-----");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	}

	public boolean addComments(Comms b) {
		
		String sql="insert into comms values(?,?,?)";
		boolean isAdded=false;
		getConnection();
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, b.getBookId());
			ps.setString(2, b.getBookName());
			ps.setString(3, b.getComments());
			int cnt=ps.executeUpdate();
			if(cnt==1){
				System.out.println("The comments have been added!");
				isAdded=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return isAdded;
	}

public Connection getConnection() {
		
		try {
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("-----CONNECTED TO DB-----");
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	}


	public void closeConnection() {
		
		if(con!=null)
			try {
				con.close();
				System.out.println("---CONNECTION TO DB CLOSED----");
			} 
		catch (SQLException e) {
				e.printStackTrace();
			}

	}
	
	
	public ArrayList<Comms> getComments() {
		String sql="select * from comms";
		getConnection();
		ArrayList<Comms> idList=new ArrayList<Comms>();
		Comms c=null;
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.clearParameters();
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				c=new Comms();
				c.setBookId(rs.getInt("bookid"));
				c.setComments(rs.getString("comments"));
				idList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return idList;
	}

	public boolean removeComment(int bookId) {
		
		String SQL="delete from comms where bookid=?";
				
				boolean isDeleted=false;
				getConnection();
				
				try {
				
					PreparedStatement ps=con.prepareStatement(SQL);
					ps.clearParameters();
					ps.setInt(1, bookId);
					
					int cnt=ps.executeUpdate();
					
					if(cnt==1)
					{
						isDeleted=true;
						System.out.println("----Comments DELETED SUCCESSFULLY");
					}
					
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				finally{
					closeConnection();
				}
				return isDeleted;

			}
}

