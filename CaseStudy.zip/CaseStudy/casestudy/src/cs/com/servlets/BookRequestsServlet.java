package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.DaoImpl.BooksDaoImpl;
import cs.com.DaoImpl.IssueDaoImpl;
import cs.com.daos.BooksDAO;
import cs.com.daos.IssueDAO;
import cs.com.models.Issue_Details;

public class BookRequestsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BooksDaoImpl bd=new BooksDaoImpl();
	IssueDaoImpl idao=new IssueDaoImpl();
	Issue_Details id=new Issue_Details();
	
	public void init(ServletConfig config) throws ServletException {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
		HttpSession session=request.getSession();
		
		String choose=request.getParameter("choose");
		
		String remarks=request.getParameter("remarks");
		String userName=(String)session.getAttribute("userName");
		String bookidd=request.getParameter("bookId");
		int bookId=0;
		if(bookidd==null)
		{
			
			response.sendRedirect("bookrequests.jsp");
			bookId=0;
		}
		else
		{
		bookId=Integer.parseInt(bookidd);
		}
		if(choose==null || remarks==null || bookId==0)
		{
			response.sendRedirect("bookrequests.jsp");
		}
		Issue_Details id=idao.getIssueDetails(bookId,"Pending");
		
		if(id.getRequest().equals("Issue")){
			if(choose.equals("Approved")){
				id.setIssueDate(new Date(System.currentTimeMillis()));
				id.setRemarks(remarks);
				bd.issueBook(bookId,id);
				out.println("<h3><b><i>Issue was approved</i></b></h3>");
				rd.include(request, response);
				
			}
			else if(choose.equals("Rejected"))
			{
				id.setBookId(bookId);
				id.setRequest("Issue");
				id.setRemarks(remarks);
				idao.updateRejectDetails(bookId, id);
				out.println("<h3><b><i>Issue was rejected</i></b></h3>");
				rd.include(request, response);
			}
		}
		else
		{
			if(choose.equals("Approved")){
				id.setRemarks(remarks);
				bd.returnBook(bookId,id);
				out.println("<h3><b><i>Return was approved</i></b></h3>");
				rd.include(request, response);
				
			}
			else if(choose.equals("Rejected"))
			{
				id.setBookId(bookId);
				id.setRequest("Return");
				id.setRemarks(remarks);
				idao.updateRejectDetails(bookId, id);
				out.println("<h3><b><i>Return was rejected</i></b></h3>");
				rd.include(request, response);
			}
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
