/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.qantas.servicesfactory;

import com.qantas.services.EmployeeService;
import com.qantas.services.LoginService;

/**
 *
 * @author USHA KIRAN
 */
public class ServiceFactory {

    private static EmployeeService employeeService = null;
    private static LoginService loginService = null;

    public static EmployeeService getEmployeeService( ){
        if(employeeService == null){
            employeeService = new EmployeeService( );
        }
        else{
            return employeeService;
        }
        return employeeService;
    }

    public static LoginService getLoginService( ){
        if(loginService==null){
            loginService= new LoginService( );
        }
        else{
            return loginService;
        }
        return loginService;
    }

}
